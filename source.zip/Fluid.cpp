class SPHSolver {
    void solve() {
        #pragma omp parallel for  
        for (auto& particle : particles) {
            
        }
    }
};