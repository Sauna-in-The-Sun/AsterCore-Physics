class GJKSolver {
    bool solve(const Collider& a, const Collider& b, ContactManifold& out);
};